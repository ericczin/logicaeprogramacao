﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio07 : Form
    {
        public FrmExercicio07()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblPequenas_Click(object sender, EventArgs e)
        {

        }

        private void txtPequenas_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblCamisetas1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float cam1 = float.Parse(txtPequenas.Text);
            float cam2 = float.Parse(txtMedias.Text);
            float cam3 = float.Parse(txtGrandes.Text);

            float total;

            total = (cam1 * 12) + (cam2 * 16) + (cam3 * 22);
            lblResultado.Text = "R$ " + total;

        }
    }
}
