﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmEx1 : Form
    {
        public FrmEx1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

            soma = num1 + num3;
            lblRSoma.Text = "O resultado da soma entre o número 1 e 3 é " + soma;


        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);

            float media = (num1 + num2 + num3) / 3;
            lblRMedia.Text = "A média dos números é " + media;

        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float porc1, porc2, porc3;
            float total = (num1 + num2 + num3);

            porc1 = num1 / total;
            porc2 = num2 / total;
            porc3 = num3 / total;

            lblRPorcentagem.Text = "Número1: " + porc1 + "% || " + "Número2: " + porc2 + "% || " + "Número3: " + porc3 + "%";
        }
    }
}
