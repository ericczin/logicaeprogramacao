﻿namespace AppLista03
{
    partial class FrmEx1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblRSoma = new System.Windows.Forms.Label();
            this.lblRMedia = new System.Windows.Forms.Label();
            this.lblRPorcentagem = new System.Windows.Forms.Label();
            this.pnlAzul = new System.Windows.Forms.Panel();
            this.pnlAzul.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(53, 106);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(96, 22);
            this.lblNum1.TabIndex = 0;
            this.lblNum1.Text = "Número 1";
            this.lblNum1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(261, 106);
            this.lblNum2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(96, 22);
            this.lblNum2.TabIndex = 1;
            this.lblNum2.Text = "Número 2";
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblNum3.Location = new System.Drawing.Point(460, 99);
            this.lblNum3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(96, 22);
            this.lblNum3.TabIndex = 2;
            this.lblNum3.Text = "Número 3";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(51, 127);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(180, 30);
            this.txtNum1.TabIndex = 3;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(259, 127);
            this.txtNum2.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(180, 30);
            this.txtNum2.TabIndex = 4;
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(465, 127);
            this.txtNum3.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(180, 30);
            this.txtNum3.TabIndex = 5;
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(143, 211);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(115, 53);
            this.btnSoma.TabIndex = 6;
            this.btnSoma.Text = "Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(287, 211);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(115, 53);
            this.btnMedia.TabIndex = 7;
            this.btnMedia.Text = "Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.Location = new System.Drawing.Point(428, 211);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(152, 53);
            this.btnPorcentagem.TabIndex = 8;
            this.btnPorcentagem.Text = "Porcentagem";
            this.btnPorcentagem.UseVisualStyleBackColor = true;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(53, 16);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(117, 22);
            this.lblTitulo.TabIndex = 9;
            this.lblTitulo.Text = "Exercício 01";
            this.lblTitulo.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblRSoma
            // 
            this.lblRSoma.AutoSize = true;
            this.lblRSoma.Location = new System.Drawing.Point(47, 307);
            this.lblRSoma.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblRSoma.Name = "lblRSoma";
            this.lblRSoma.Size = new System.Drawing.Size(155, 22);
            this.lblRSoma.TabIndex = 10;
            this.lblRSoma.Text = "Resultado Soma:\r\n";
            // 
            // lblRMedia
            // 
            this.lblRMedia.AutoSize = true;
            this.lblRMedia.Location = new System.Drawing.Point(47, 329);
            this.lblRMedia.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblRMedia.Name = "lblRMedia";
            this.lblRMedia.Size = new System.Drawing.Size(160, 22);
            this.lblRMedia.TabIndex = 11;
            this.lblRMedia.Text = "Resultado Média:\r\n";
            // 
            // lblRPorcentagem
            // 
            this.lblRPorcentagem.AutoSize = true;
            this.lblRPorcentagem.Location = new System.Drawing.Point(47, 351);
            this.lblRPorcentagem.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblRPorcentagem.Name = "lblRPorcentagem";
            this.lblRPorcentagem.Size = new System.Drawing.Size(223, 22);
            this.lblRPorcentagem.TabIndex = 12;
            this.lblRPorcentagem.Text = "Resultado Porcentagem:\r\n";
            // 
            // pnlAzul
            // 
            this.pnlAzul.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.pnlAzul.Controls.Add(this.lblTitulo);
            this.pnlAzul.Controls.Add(this.lblNum2);
            this.pnlAzul.Controls.Add(this.lblNum1);
            this.pnlAzul.Location = new System.Drawing.Point(-6, -7);
            this.pnlAzul.Name = "pnlAzul";
            this.pnlAzul.Size = new System.Drawing.Size(727, 186);
            this.pnlAzul.TabIndex = 13;
            // 
            // FrmEx1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(711, 435);
            this.Controls.Add(this.lblRPorcentagem);
            this.Controls.Add(this.lblRMedia);
            this.Controls.Add(this.lblRSoma);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.pnlAzul);
            this.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "FrmEx1";
            this.Text = "Exercicio 01";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnlAzul.ResumeLayout(false);
            this.pnlAzul.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblRSoma;
        private System.Windows.Forms.Label lblRMedia;
        private System.Windows.Forms.Label lblRPorcentagem;
        private System.Windows.Forms.Panel pnlAzul;
    }
}

