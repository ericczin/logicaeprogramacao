﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio06 : Form
    {
        public FrmExercicio06()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float num = float.Parse(txtNumero.Text);
            float cubo;

            cubo = (num * num) * num;

            lblResultado.Text = "Cubo do número: " + cubo;
        }

        private void lblResultado_Click(object sender, EventArgs e)
        {

        }
    }
}
