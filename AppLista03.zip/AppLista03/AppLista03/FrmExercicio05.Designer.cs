﻿namespace AppLista03
{
    partial class FrmExercicio05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.txtBase = new System.Windows.Forms.TextBox();
            this.lblAltura = new System.Windows.Forms.Label();
            this.lblBase = new System.Windows.Forms.Label();
            this.lblResultadoP = new System.Windows.Forms.Label();
            this.lblResultadoA = new System.Windows.Forms.Label();
            this.btnPerimetro = new System.Windows.Forms.Button();
            this.btnArea = new System.Windows.Forms.Button();
            this.pnlRoxo = new System.Windows.Forms.Panel();
            this.pnlRoxo.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAltura
            // 
            this.txtAltura.Location = new System.Drawing.Point(157, 139);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(236, 30);
            this.txtAltura.TabIndex = 0;
            // 
            // txtBase
            // 
            this.txtBase.Location = new System.Drawing.Point(61, 64);
            this.txtBase.Name = "txtBase";
            this.txtBase.Size = new System.Drawing.Size(236, 30);
            this.txtBase.TabIndex = 1;
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Location = new System.Drawing.Point(57, 117);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(253, 22);
            this.lblAltura.TabIndex = 2;
            this.lblAltura.Text = "Digite a altura do retângulo:";
            this.lblAltura.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblBase
            // 
            this.lblBase.AutoSize = true;
            this.lblBase.Location = new System.Drawing.Point(57, 39);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(240, 22);
            this.lblBase.TabIndex = 3;
            this.lblBase.Text = "Digite a base do retângulo:";
            this.lblBase.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblResultadoP
            // 
            this.lblResultadoP.AutoSize = true;
            this.lblResultadoP.Location = new System.Drawing.Point(71, 290);
            this.lblResultadoP.Name = "lblResultadoP";
            this.lblResultadoP.Size = new System.Drawing.Size(106, 22);
            this.lblResultadoP.TabIndex = 4;
            this.lblResultadoP.Text = "Perímetro:";
            this.lblResultadoP.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblResultadoA
            // 
            this.lblResultadoA.AutoSize = true;
            this.lblResultadoA.Location = new System.Drawing.Point(121, 321);
            this.lblResultadoA.Name = "lblResultadoA";
            this.lblResultadoA.Size = new System.Drawing.Size(56, 22);
            this.lblResultadoA.TabIndex = 5;
            this.lblResultadoA.Text = "Área:";
            this.lblResultadoA.Click += new System.EventHandler(this.label4_Click);
            // 
            // btnPerimetro
            // 
            this.btnPerimetro.BackColor = System.Drawing.Color.Orchid;
            this.btnPerimetro.ForeColor = System.Drawing.Color.White;
            this.btnPerimetro.Location = new System.Drawing.Point(63, 200);
            this.btnPerimetro.Name = "btnPerimetro";
            this.btnPerimetro.Size = new System.Drawing.Size(114, 40);
            this.btnPerimetro.TabIndex = 6;
            this.btnPerimetro.Text = "Perímetro";
            this.btnPerimetro.UseVisualStyleBackColor = false;
            this.btnPerimetro.Click += new System.EventHandler(this.btnPerimetro_Click);
            // 
            // btnArea
            // 
            this.btnArea.BackColor = System.Drawing.Color.Orchid;
            this.btnArea.ForeColor = System.Drawing.Color.White;
            this.btnArea.Location = new System.Drawing.Point(183, 200);
            this.btnArea.Name = "btnArea";
            this.btnArea.Size = new System.Drawing.Size(114, 41);
            this.btnArea.TabIndex = 7;
            this.btnArea.Text = "Área";
            this.btnArea.UseVisualStyleBackColor = false;
            this.btnArea.Click += new System.EventHandler(this.button2_Click);
            // 
            // pnlRoxo
            // 
            this.pnlRoxo.BackColor = System.Drawing.Color.MediumPurple;
            this.pnlRoxo.Controls.Add(this.txtBase);
            this.pnlRoxo.Controls.Add(this.lblResultadoA);
            this.pnlRoxo.Controls.Add(this.btnArea);
            this.pnlRoxo.Controls.Add(this.lblResultadoP);
            this.pnlRoxo.Controls.Add(this.lblBase);
            this.pnlRoxo.Controls.Add(this.btnPerimetro);
            this.pnlRoxo.Controls.Add(this.lblAltura);
            this.pnlRoxo.Location = new System.Drawing.Point(96, -3);
            this.pnlRoxo.Name = "pnlRoxo";
            this.pnlRoxo.Size = new System.Drawing.Size(367, 442);
            this.pnlRoxo.TabIndex = 8;
            // 
            // FrmExercicio05
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(584, 421);
            this.Controls.Add(this.txtAltura);
            this.Controls.Add(this.pnlRoxo);
            this.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "FrmExercicio05";
            this.Text = "FrmExercicio05";
            this.Load += new System.EventHandler(this.FrmExercicio05_Load);
            this.pnlRoxo.ResumeLayout(false);
            this.pnlRoxo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.TextBox txtBase;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.Label lblResultadoP;
        private System.Windows.Forms.Label lblResultadoA;
        private System.Windows.Forms.Button btnPerimetro;
        private System.Windows.Forms.Button btnArea;
        private System.Windows.Forms.Panel pnlRoxo;
    }
}