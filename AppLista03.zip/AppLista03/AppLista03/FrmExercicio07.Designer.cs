﻿namespace AppLista03
{
    partial class FrmExercicio07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlEscuro = new System.Windows.Forms.Panel();
            this.pnlClaro = new System.Windows.Forms.Panel();
            this.txtPequenas = new System.Windows.Forms.TextBox();
            this.txtMedias = new System.Windows.Forms.TextBox();
            this.txtGrandes = new System.Windows.Forms.TextBox();
            this.lblPequenas = new System.Windows.Forms.Label();
            this.lblMedias = new System.Windows.Forms.Label();
            this.lblGrandes = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblArrecadado = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlEscuro.SuspendLayout();
            this.pnlClaro.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlEscuro
            // 
            this.pnlEscuro.BackColor = System.Drawing.Color.Brown;
            this.pnlEscuro.Controls.Add(this.btnCalcular);
            this.pnlEscuro.Controls.Add(this.lblGrandes);
            this.pnlEscuro.Controls.Add(this.lblMedias);
            this.pnlEscuro.Controls.Add(this.lblPequenas);
            this.pnlEscuro.Controls.Add(this.txtGrandes);
            this.pnlEscuro.Controls.Add(this.txtMedias);
            this.pnlEscuro.Controls.Add(this.txtPequenas);
            this.pnlEscuro.Location = new System.Drawing.Point(-7, -9);
            this.pnlEscuro.Name = "pnlEscuro";
            this.pnlEscuro.Size = new System.Drawing.Size(425, 346);
            this.pnlEscuro.TabIndex = 0;
            this.pnlEscuro.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pnlClaro
            // 
            this.pnlClaro.BackColor = System.Drawing.Color.LightCoral;
            this.pnlClaro.Controls.Add(this.lblResultado);
            this.pnlClaro.Controls.Add(this.lblArrecadado);
            this.pnlClaro.Location = new System.Drawing.Point(414, 0);
            this.pnlClaro.Name = "pnlClaro";
            this.pnlClaro.Size = new System.Drawing.Size(346, 350);
            this.pnlClaro.TabIndex = 1;
            this.pnlClaro.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // txtPequenas
            // 
            this.txtPequenas.Location = new System.Drawing.Point(37, 53);
            this.txtPequenas.Name = "txtPequenas";
            this.txtPequenas.Size = new System.Drawing.Size(322, 30);
            this.txtPequenas.TabIndex = 0;
            this.txtPequenas.TextChanged += new System.EventHandler(this.txtPequenas_TextChanged);
            // 
            // txtMedias
            // 
            this.txtMedias.Location = new System.Drawing.Point(37, 135);
            this.txtMedias.Name = "txtMedias";
            this.txtMedias.Size = new System.Drawing.Size(322, 30);
            this.txtMedias.TabIndex = 1;
            // 
            // txtGrandes
            // 
            this.txtGrandes.Location = new System.Drawing.Point(37, 222);
            this.txtGrandes.Name = "txtGrandes";
            this.txtGrandes.Size = new System.Drawing.Size(322, 30);
            this.txtGrandes.TabIndex = 2;
            // 
            // lblPequenas
            // 
            this.lblPequenas.AutoSize = true;
            this.lblPequenas.ForeColor = System.Drawing.Color.White;
            this.lblPequenas.Location = new System.Drawing.Point(19, 18);
            this.lblPequenas.Name = "lblPequenas";
            this.lblPequenas.Size = new System.Drawing.Size(386, 22);
            this.lblPequenas.TabIndex = 3;
            this.lblPequenas.Text = "Digite a quantidade de camisetas pequenas:\r\n";
            this.lblPequenas.Click += new System.EventHandler(this.lblPequenas_Click);
            // 
            // lblMedias
            // 
            this.lblMedias.AutoSize = true;
            this.lblMedias.ForeColor = System.Drawing.Color.White;
            this.lblMedias.Location = new System.Drawing.Point(24, 100);
            this.lblMedias.Name = "lblMedias";
            this.lblMedias.Size = new System.Drawing.Size(366, 22);
            this.lblMedias.TabIndex = 4;
            this.lblMedias.Text = "Digite a quantidade de camisetas médias:";
            // 
            // lblGrandes
            // 
            this.lblGrandes.AutoSize = true;
            this.lblGrandes.ForeColor = System.Drawing.Color.White;
            this.lblGrandes.Location = new System.Drawing.Point(24, 184);
            this.lblGrandes.Name = "lblGrandes";
            this.lblGrandes.Size = new System.Drawing.Size(373, 22);
            this.lblGrandes.TabIndex = 5;
            this.lblGrandes.Text = "Digite a quantidade de camisetas grandes:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.Firebrick;
            this.btnCalcular.ForeColor = System.Drawing.Color.White;
            this.btnCalcular.Location = new System.Drawing.Point(111, 272);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(168, 48);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblArrecadado
            // 
            this.lblArrecadado.AutoSize = true;
            this.lblArrecadado.Location = new System.Drawing.Point(80, 101);
            this.lblArrecadado.Name = "lblArrecadado";
            this.lblArrecadado.Size = new System.Drawing.Size(166, 22);
            this.lblArrecadado.TabIndex = 0;
            this.lblArrecadado.Text = "Valor arrecadado:";
            this.lblArrecadado.Click += new System.EventHandler(this.lblCamisetas1_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(125, 134);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(33, 22);
            this.lblResultado.TabIndex = 1;
            this.lblResultado.Text = "R$";
            // 
            // FrmExercicio07
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(736, 323);
            this.Controls.Add(this.pnlClaro);
            this.Controls.Add(this.pnlEscuro);
            this.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "FrmExercicio07";
            this.Text = "FrmExercicio07";
            this.pnlEscuro.ResumeLayout(false);
            this.pnlEscuro.PerformLayout();
            this.pnlClaro.ResumeLayout(false);
            this.pnlClaro.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlEscuro;
        private System.Windows.Forms.Label lblPequenas;
        private System.Windows.Forms.TextBox txtGrandes;
        private System.Windows.Forms.TextBox txtMedias;
        private System.Windows.Forms.TextBox txtPequenas;
        private System.Windows.Forms.Panel pnlClaro;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblGrandes;
        private System.Windows.Forms.Label lblMedias;
        private System.Windows.Forms.Label lblArrecadado;
        private System.Windows.Forms.Label lblResultado;
    }
}