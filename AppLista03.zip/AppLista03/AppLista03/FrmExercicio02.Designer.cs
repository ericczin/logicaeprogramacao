﻿namespace AppLista03
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtPagamento = new System.Windows.Forms.TextBox();
            this.lblPagamento = new System.Windows.Forms.Label();
            this.lblGasolina = new System.Windows.Forms.Label();
            this.txtGasolina = new System.Windows.Forms.TextBox();
            this.lblLitros = new System.Windows.Forms.Label();
            this.lblTotalLitros = new System.Windows.Forms.Label();
            this.pnlLitros = new System.Windows.Forms.Panel();
            this.pnlResultado = new System.Windows.Forms.Panel();
            this.pnlLitros.SuspendLayout();
            this.pnlResultado.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(72, 188);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(133, 46);
            this.btnCalcular.TabIndex = 0;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtPagamento
            // 
            this.txtPagamento.Location = new System.Drawing.Point(47, 64);
            this.txtPagamento.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.txtPagamento.Name = "txtPagamento";
            this.txtPagamento.Size = new System.Drawing.Size(180, 30);
            this.txtPagamento.TabIndex = 2;
            // 
            // lblPagamento
            // 
            this.lblPagamento.AutoSize = true;
            this.lblPagamento.Location = new System.Drawing.Point(43, 37);
            this.lblPagamento.Name = "lblPagamento";
            this.lblPagamento.Size = new System.Drawing.Size(184, 22);
            this.lblPagamento.TabIndex = 3;
            this.lblPagamento.Text = "Valor do pagamento";
            this.lblPagamento.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblGasolina
            // 
            this.lblGasolina.AutoSize = true;
            this.lblGasolina.Location = new System.Drawing.Point(43, 99);
            this.lblGasolina.Name = "lblGasolina";
            this.lblGasolina.Size = new System.Drawing.Size(232, 22);
            this.lblGasolina.TabIndex = 5;
            this.lblGasolina.Text = "Preço do litro da gasolina";
            // 
            // txtGasolina
            // 
            this.txtGasolina.Location = new System.Drawing.Point(47, 126);
            this.txtGasolina.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.txtGasolina.Name = "txtGasolina";
            this.txtGasolina.Size = new System.Drawing.Size(180, 30);
            this.txtGasolina.TabIndex = 4;
            // 
            // lblLitros
            // 
            this.lblLitros.AutoSize = true;
            this.lblLitros.Location = new System.Drawing.Point(6, 9);
            this.lblLitros.Name = "lblLitros";
            this.lblLitros.Size = new System.Drawing.Size(174, 22);
            this.lblLitros.TabIndex = 6;
            this.lblLitros.Text = "Litros abastecidos:";
            // 
            // lblTotalLitros
            // 
            this.lblTotalLitros.AutoSize = true;
            this.lblTotalLitros.Location = new System.Drawing.Point(87, 31);
            this.lblTotalLitros.Name = "lblTotalLitros";
            this.lblTotalLitros.Size = new System.Drawing.Size(21, 22);
            this.lblTotalLitros.TabIndex = 7;
            this.lblTotalLitros.Text = "0";
            this.lblTotalLitros.Click += new System.EventHandler(this.lblTotalLitros_Click);
            // 
            // pnlLitros
            // 
            this.pnlLitros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.pnlLitros.Controls.Add(this.lblGasolina);
            this.pnlLitros.Controls.Add(this.txtGasolina);
            this.pnlLitros.Controls.Add(this.lblPagamento);
            this.pnlLitros.Controls.Add(this.txtPagamento);
            this.pnlLitros.Controls.Add(this.btnCalcular);
            this.pnlLitros.Controls.Add(this.pnlResultado);
            this.pnlLitros.Location = new System.Drawing.Point(55, -9);
            this.pnlLitros.Name = "pnlLitros";
            this.pnlLitros.Size = new System.Drawing.Size(285, 355);
            this.pnlLitros.TabIndex = 8;
            // 
            // pnlResultado
            // 
            this.pnlResultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.pnlResultado.Controls.Add(this.lblLitros);
            this.pnlResultado.Controls.Add(this.lblTotalLitros);
            this.pnlResultado.Location = new System.Drawing.Point(47, 263);
            this.pnlResultado.Name = "pnlResultado";
            this.pnlResultado.Size = new System.Drawing.Size(190, 67);
            this.pnlResultado.TabIndex = 8;
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(412, 333);
            this.Controls.Add(this.pnlLitros);
            this.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio02";
            this.Load += new System.EventHandler(this.FrmExercicio02_Load);
            this.pnlLitros.ResumeLayout(false);
            this.pnlLitros.PerformLayout();
            this.pnlResultado.ResumeLayout(false);
            this.pnlResultado.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtPagamento;
        private System.Windows.Forms.Label lblPagamento;
        private System.Windows.Forms.Label lblGasolina;
        private System.Windows.Forms.TextBox txtGasolina;
        private System.Windows.Forms.Label lblLitros;
        private System.Windows.Forms.Label lblTotalLitros;
        private System.Windows.Forms.Panel pnlLitros;
        private System.Windows.Forms.Panel pnlResultado;
    }
}