﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void FrmExercicio02_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float valorPagamento = float.Parse(txtPagamento.Text);
            float precoGasolina = float.Parse(txtGasolina.Text);
            float totalLitros;

            totalLitros = valorPagamento / precoGasolina;
            lblTotalLitros.Text = "" + totalLitros;
        }

        private void lblTotalLitros_Click(object sender, EventArgs e)
        {

        }
    }
}
